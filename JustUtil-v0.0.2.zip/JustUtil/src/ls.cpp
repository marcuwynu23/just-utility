#include <iostream>
#include "header\runner.h"

int main(){ peculiar::runExe("dir /ON /B"); return 0;}