#include <iostream>
#include "header\runner.h"

int main()
{
	peculiar::runExe("explorer .");
	peculiar::print("open file explorer in current directory");
	return 0;
} 
