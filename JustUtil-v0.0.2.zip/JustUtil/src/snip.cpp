#include <iostream>
#include "header\runner.h"

int main(){	peculiar::runExe("snippingtool");}